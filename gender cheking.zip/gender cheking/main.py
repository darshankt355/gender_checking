from flask import Flask,render_template,request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/gender', methods=['POST'])
def gender_cheking():
    names=request.form['name']
    name=request.form['name'].lower()
    if name[-1]=='a' or name[-1]=='i' or name[-1]=='u':
        
        return render_template('index.html',name=names,gender="Female")
    else:
        
        return render_template('index.html',name=names,gender="Male")
if __name__ == '__main__':
    app.run(debug=True)
